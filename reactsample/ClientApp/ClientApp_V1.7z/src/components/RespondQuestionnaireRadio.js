import React, { Component } from 'react'

class RespondQuestionnaireRadio  extends Component {
    constructor(props) {
        super(props);
        this.state = {  };
    }
    render() {
        let question = this.props.question;
        let qi = this.props.questionItems.get(question.questionId);
        return (
            <div>
                <label> {this.props.question.questionText}</label>
                <div >
                    {
                        this.props.question.options.map(opt =>{                            
                            let qid = opt.optionId;
                            return (
                                <label key={qid} >
                                    <input  type='radio'
                                           name={qid}
                                     />
                                    <span>{opt.optionText}</span>
                                </label>
                            );}

                        )
                    }
                </div>
            </div>
        );
    }
}

export default RespondQuestionnaireRadio;