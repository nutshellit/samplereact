import React, { Component } from 'react';
import RespondQuestionnaireSection from './RespondQuestionnaireSection';
class RespondQuestionnaire extends Component {
    constructor(props) {
        super(props);
        this.state = { questionnaire: {}, loading: true };
        let url = `/api/questionnaire/getquestionnaire/${props.match.params.questionnairename}`;
        fetch(url)
            .then(response => response.json())
            .then(data => {
                this.setupState(data);
            });
        this.handleQuestionChange = this.handleQuestionChange.bind(this);
    }

    handleQuestionChange(change)
    {
        //see http://jsbin.com/rozayedibe/edit?js,console,output
        //see https://medium.freecodecamp.org/reactjs-pass-parameters-to-event-handlers-ca1f5c422b9
        console.log(change);
    }

    updateResponse(data, questionItems) {
        let updatedQuestionItems = new Map();
        data.sections.forEach(section => {
            section.questions.forEach(question => {
                let existingQuestionItem = questionItems.get(question.questionId);
                if (question.parentQuestionId != null) {
                    console.log('-------------');
                    let parentQuestionResponse = questionItems.get(question.parentQuestionId);
                    if (parentQuestionResponse.response == question.parentQuestionOptionId) {
                        let qr = { questionId: existingQuestionItem.questionId, isHidden: false, response: existingQuestionItem.response };
                        updatedQuestionItems.set(question.questionId, qr)
                    }
                    else {
                        let qr = { questionId: existingQuestionItem.questionId, isHidden: true, response: existingQuestionItem.response };
                        updatedQuestionItems.set(question.questionId, qr);
                    }
                }
                else {
                    updatedQuestionItems.set(question.questionId, existingQuestionItem);
                }
            });
        });
        return updatedQuestionItems;
    }

    setupState(data) {
        var questionItems = new Map();
        data.sections.forEach(section => {
            section.questions.forEach(q => {
                let qr = { questionId: q.questionId, isHidden: false, response: '' };
                questionItems.set(q.questionId, qr);
            }
            )
        });
        questionItems = this.updateResponse(data, questionItems);
        this.setState({ questionnaire: data, questionItems: questionItems, loading: false });
    }

    render() {
        let contents = this.state.loading
            ? <p><em>Loading....</em></p>
            : <div><h2>Questionnaire : {this.state.questionnaire.name} </h2>
                {this.state.questionnaire.sections.map(s =>
                 <RespondQuestionnaireSection
                    key={s.sectionName}
                    section={s}
                    questionItems={this.state.questionItems} 
                    onQuestionChange={this.handleQuestionChange}
                    />)}

            </div>
        return (
            <div>
                {contents}
            </div>
        );
    }
}

export default RespondQuestionnaire;